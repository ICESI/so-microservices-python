from flask import Flask
from gm_analytics import settings
# import logging.config
import logging

app = Flask(__name__, instance_relative_config=True)
# logging.config.fileConfig('logging.conf')
log = logging.getLogger(__name__)

@app.route('/hello')
def hello():
    log.info('info message')
    log.debug('debug message')
    return 'Hello, World!'

if __name__ == "__main__":
    app.config.from_object('gm_analytics.settings')
    print(app.config['ENV'])
    print(app.config['FLASK_ENV'])
    # app.run(host='0.0.0.0', port=8088)
    app.run()
