# Flask settings
FLASK_SERVER_NAME = '0.0.0.0:5001'
FLASK_ENV = 'development'
ENV = 'development'
SERVER_NAME = '0.0.0.0:5001'
