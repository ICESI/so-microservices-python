import connexion
from gm_analytics import settings

app = connexion.FlaskApp(__name__, specification_dir='swagger/')
app.config.from_object('settings')
app.add_api('indexer.yaml', validate_responses=True)

if __name__ == "__main__":
    app.run(server='tornado', port=8088)


# python3 gm_progress/__init__.py
