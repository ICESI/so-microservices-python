def get_progress(org, repo, branch=None):
    print("URL is {org}/{repo}/{branch}, from API!".
          format(org=org, repo=repo, branch=branch))

    return [{'commits_count': 10, 'yyyymmdd_date': '20180101'}]
