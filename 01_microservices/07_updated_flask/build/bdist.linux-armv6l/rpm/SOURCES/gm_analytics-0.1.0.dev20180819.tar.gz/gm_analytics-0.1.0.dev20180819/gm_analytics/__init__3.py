import connexion
from flask import Flask

def create_app():
    app = connexion.FlaskApp(__name__, specification_dir='swagger/')
    app.add_api('indexer.yaml', validate_responses=True, strict_validation=True)
    return app

# This is not working
